#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAXLINE 1024
#define PORT 5777

int main()
{
    int sockfd;
    char sendline[MAXLINE], recvline[MAXLINE];

    struct sockaddr_in servaddr, cliaddr;
    socklen_t len;

    /* Create UDP socket */
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    if (sockfd < 0)
    {
        perror("Socket error");
        exit(1);
    }

    /* Server address */
    memset(&servaddr, 0, sizeof(servaddr));

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    /* Bind socket to port */
    if (bind(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
    {
        perror("Bind error");
        close(sockfd);
        exit(1);
    }

    printf("UDP SERVER STARTED...\n");
    printf("Waiting for client...\n");

    len = sizeof(cliaddr);

    while (1)
    {
        /* SERVER RECEIVE */
        int n = recvfrom(sockfd, recvline, MAXLINE - 1, 0,
                         (struct sockaddr *)&cliaddr, &len);

        recvline[n] = '\0';

        printf("Client: %s\n", recvline);

        if (strcmp(recvline, "exit") == 0)
            break;

        /* SERVER SEND */
        printf("Server: ");
        fgets(sendline, MAXLINE, stdin);

        sendline[strcspn(sendline, "\n")] = '\0';

        sendto(sockfd, sendline, strlen(sendline), 0,
               (struct sockaddr *)&cliaddr, len);

        if (strcmp(sendline, "exit") == 0)
            break;
    }

    close(sockfd);

    return 0;
}

