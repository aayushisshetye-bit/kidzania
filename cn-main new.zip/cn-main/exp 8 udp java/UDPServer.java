import java.net.*;

public class UDPServer {
    public static void main(String[] args) {
        try {
            DatagramSocket ds = new DatagramSocket(6666);

            byte[] buffer = new byte[1024];

            DatagramPacket dp = new DatagramPacket(
                buffer, buffer.length
            );

            ds.receive(dp);

            String str = new String(dp.getData(), 0, dp.getLength());

            System.out.println("message = " + str);

            ds.close();
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}