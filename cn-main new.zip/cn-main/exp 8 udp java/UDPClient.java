import java.net.*;

public class UDPClient {
    public static void main(String[] args) {
        try {
            DatagramSocket ds = new DatagramSocket();

            String str = "Hello Server";

            byte[] buffer = str.getBytes();

            InetAddress ip = InetAddress.getByName("localhost");

            DatagramPacket dp = new DatagramPacket(
                buffer, buffer.length, ip, 6666
            );

            ds.send(dp);

            ds.close();
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}